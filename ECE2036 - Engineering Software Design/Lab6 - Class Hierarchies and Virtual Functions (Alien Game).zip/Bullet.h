#ifndef BULLET_H 
#define BULLET_H

#include "ScreenObject.h" 

#define BULLET_HEIGHT 8 
#define BULLET_WIDTH 3
#define BULLET_SPEED -8
#define W 0xFFFFFF

class Bullet: public ScreenObject 
{
public:
    Bullet(int, int); 

    virtual void draw(uLCD_4DGL &inLCD); 
    virtual void update(uLCD_4DGL &inLCD);
    virtual void remove(uLCD_4DGL &inLCD);

    bool getActive(); 

    void setActive(bool);
private:
    bool active; 
};

#endif
