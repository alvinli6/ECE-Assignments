#ifndef ALIENALICE_H
#define ALIENALICE_H
#include "ScreenObject.h"

#define ALICE_SPEED 4
#define W 0xFFFFFF      //white
#define _ 0x000000      //black
#define R   0xFF0000    //red
#define G   0x00FF00    //green
#define Bl  0x0000FF    //blue

class AlienAlice: public ScreenObject
{
    
public:

    AlienAlice(int, int);
    virtual void draw(uLCD_4DGL &inLCD);
    virtual void update(uLCD_4DGL &inLCD);
    virtual void remove(uLCD_4DGL &inLCD);
    
private:
    static int alice[ALIEN_HEIGHT*ALIEN_WIDTH];
    static int removed[ALIEN_HEIGHT*ALIEN_WIDTH];
};

#endif