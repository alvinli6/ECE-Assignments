#include <iostream>
#include "ScreenObject.h"

ScreenObject::ScreenObject(int inTx, int inTy, int inSpeed)
{
    Tx = inTx;
    Bx = inTx + ALIEN_WIDTH;
    
    Ty = inTy;
    By = inTy + ALIEN_HEIGHT;
    
    speed = inSpeed;
};
void ScreenObject::setTx(int inTx)
{
    Tx = inTx;
};
void ScreenObject::setTy(int inTy)
{
    Ty = inTy;   
};
void ScreenObject::setBx(int inBx)
{
    Bx = inBx;   
};
void ScreenObject::setBy(int inBy)
{
    By = inBy;
};
void ScreenObject::setSpeed(int inSpeed)
{
    speed = inSpeed;  
};
int ScreenObject::getTx()
{
    return Tx;
};
int ScreenObject::getTy()
{
    return Ty;   
};
int ScreenObject::getBx()
{
    return Bx;   
};
int ScreenObject::getBy()
{
    return By;  
};
int ScreenObject::getSpeed()
{
    return speed;  
};