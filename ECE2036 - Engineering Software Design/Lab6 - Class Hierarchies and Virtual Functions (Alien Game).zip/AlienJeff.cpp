#include "AlienJeff.h"


int AlienJeff::jeff[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,_,_,R,R,R,_,_,_,_,
    _,R,R,R,R,R,R,R,R,R,_,
     R,R,R,R,R,R,R,R,R,R,R,
    R,R,R,R,_,R,_,R,R,R,R,
    G,G,G,R,R,G,R,R,G,G,G,
    _,_,_,_,_,G,_,_,_,_,_,
    _,_,_,_,_,G,_,_,_,_,_,
    G,G,G,G,G,G,G,G,G,G,G,
};

int AlienJeff::removed[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
};

AlienJeff::AlienJeff(int x, int y): ScreenObject(x, y, JEFF_SPEED)
{
}

void AlienJeff::draw(uLCD_4DGL &inLCD)
{
    inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, jeff);
}

void AlienJeff::update(uLCD_4DGL &inLCD)
{
    remove(inLCD);
    Tx += speed;
    Bx += speed;
    
    if (Tx > 120 - ALIEN_WIDTH)
    {
        Tx = 120 - ALIEN_WIDTH;
        Bx = 120;
        speed = speed*(-1);
    }
    else if (Tx < 0)
    {
        Tx = 0;
        Bx = ALIEN_WIDTH;
        speed = speed*(-1);
    }
    
    draw(inLCD);
}

void AlienJeff::remove(uLCD_4DGL &inLCD)
{
    inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, removed);   
}
