#include "AlienBob.h"


int AlienBob::bob[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,R,_,_,_,_,_,R,_,_,
    R,_,_,R,_,_,_,R,_,_,R,
    R,_,R,R,R,R,R,R,R,_,R,
    R,R,R,_,R,R,R,_,R,R,R,
    G,G,G,G,G,G,G,G,G,G,G,
    _,_,G,G,G,G,G,G,G,_,_,
    _,_,G,_,_,_,_,_,G,_,_,
    _,G,_,_,_,_,_,_,_,G,_,
};

int AlienBob::bobDown[ALIEN_HEIGHT * ALIEN_WIDTH] = {
    _,_,G,_,_,_,_,_,G,_,_,
    _,_,_,G,_,_,_,G,_,_,_,
    _,_,G,G,G,G,G,G,G,_,_,
    _,G,G,_,G,G,G,_,G,G,_,
    R,R,R,R,R,R,R,R,R,R,R,
    R,_,R,R,R,R,R,R,R,_,R,
    R,_,R,_,_,_,_,_,R,_,R,
    _,_,_,R,R,_,R,R,_,_,_,
};

int AlienBob::removed[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
};

AlienBob::AlienBob(int x, int y): ScreenObject(x, y, BOB_SPEED)
{
}

int AlienBob::getState()
{
    return state;   
}

void AlienBob::setState(int inState)
{
    state = inState;   
}

void AlienBob::draw(uLCD_4DGL &inLCD)
{
    if (state == 1)
    {
        inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, bob);
    }
    else
    {
        inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, bobDown);   
    }
    
}

void AlienBob::update(uLCD_4DGL &inLCD)
{
    if (state)
    {
        state = 0;   
    }
    else
    {
        state = 1;   
    }
    remove(inLCD);
    Tx += speed;
    Bx += speed;
    
    if (Tx > 120 - ALIEN_WIDTH)
    {
        Tx = 120 - ALIEN_WIDTH;
        Bx = 120;
        speed = speed*(-1);
    }
    else if (Tx < 0)
    {
        Tx = 0;
        Bx = ALIEN_WIDTH;
        speed = speed*(-1);
    }
    
    draw(inLCD);
}

void AlienBob::remove(uLCD_4DGL &inLCD)
{
    inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, removed);   
}