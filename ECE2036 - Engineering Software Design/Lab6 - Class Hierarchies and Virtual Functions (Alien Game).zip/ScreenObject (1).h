#ifndef SCREENOBJECT_H
#define SCREENOBJECT_H

#include "uLCD_4DGL.h"

#define ALIEN_HEIGHT 8
#define ALIEN_WIDTH 11

class ScreenObject
{

public:

    ScreenObject(int, int, int);
    
    virtual void draw(uLCD_4DGL &inLCD) = 0;
    virtual void update(uLCD_4DGL &inLCD) = 0;
    virtual void remove(uLCD_4DGL &inLCD) = 0;
    //getters and setters
    void setTx(int);
    void setTy(int);
    void setBx(int);
    void setBy(int);
    void setSpeed(int);
    int getTx();
    int getTy();
    int getBx();
    int getBy();
    int getSpeed();
protected:
    int Tx;     //Top left and bottom left coordinate of a screen object
    int Ty;
    int Bx;
    int By;   
    int speed;
};

#endif