#ifndef ALIENALVIN_H
#define ALIENALVIN_H
#include "ScreenObject.h"

#define ALVIN_SPEED 3
#define W 0xFFFFFF      //white
#define _ 0x000000      //black
#define R   0xFF0000    //red
#define G   0x00FF00    //green
#define Bl  0x0000FF    //blue

class AlienAlvin: public ScreenObject
{
    
public:

    AlienAlvin(int, int);
    virtual void draw(uLCD_4DGL &inLCD);
    virtual void update(uLCD_4DGL &inLCD);
    virtual void remove(uLCD_4DGL &inLCD);
    
private:
    static int alvin[ALIEN_HEIGHT*ALIEN_WIDTH];
    static int removed[ALIEN_HEIGHT*ALIEN_WIDTH];
};

#endif