#include "AlienAlvin.h"


int AlienAlvin::alvin[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,_,_,R,R,R,_,_,_,_,
    _,R,R,R,R,R,R,R,R,R,_,
     R,R,R,R,R,R,R,R,R,R,R,
    R,R,R,_,_,R,_,_,R,R,R,
    G,G,G,G,G,G,G,G,G,G,G,
    G,G,_,_,G,G,G,_,_,G,G,
    G,G,_,_,G,G,G,_,_,G,G,
    G,G,_,_,G,G,G,_,_,G,G,
};

int AlienAlvin::removed[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
};

AlienAlvin::AlienAlvin(int x, int y): ScreenObject(x, y, ALVIN_SPEED)
{
}

void AlienAlvin::draw(uLCD_4DGL &inLCD)
{
    inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, alvin);
}

void AlienAlvin::update(uLCD_4DGL &inLCD)
{
    remove(inLCD);
    Tx += speed;
    Bx += speed;
    
    if (Tx > 120 - ALIEN_WIDTH)
    {
        Tx = 120 - ALIEN_WIDTH;
        Bx = 120;
        speed = speed*(-1);
    }
    else if (Tx < 0)
    {
        Tx = 0;
        Bx = ALIEN_WIDTH;
        speed = speed*(-1);
    }
    
    draw(inLCD);
}

void AlienAlvin::remove(uLCD_4DGL &inLCD)
{
    inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, removed);   
}
