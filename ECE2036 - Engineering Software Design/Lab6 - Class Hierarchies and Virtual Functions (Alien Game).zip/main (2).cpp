// skeleton code for ECE 2036 thermostat lab
// code must be added by students
#include "mbed.h"
#include "TMP36.h"
#include "SDFileSystem.h"
#include "uLCD_4DGL.h"
#include "PinDetect.h"
#include "Speaker.h"
// must add your new class code to the project file Shiftbrite.h
#include "Shiftbrite.h"
#include "AlienAlice.h"
#include "AlienBob.h"
#include "AlienAlvin.h"
#include "AlienJeff.h"
#include "Ship.h"
#include "MMA8452.h"
#include <vector>
#include "Bullet.h"

uLCD_4DGL uLCD(p9, p10, p11); //create a global lcd object
PinDetect fire(p21);      //create a global left button object

Serial pc(USBTX,USBRX);
MMA8452 acc(p28, p27, 40000);

Speaker mySpeaker(p26);     //instantiate speaker object for startup tune
Timer t;

int numLeft = 0;
bool bullet = false;


vector<ScreenObject*> objects;

void switchFire()
{
    bullet = true;   
}

void buttonSet()
{
    fire.mode(PullUp);
    wait(0.3);
    fire.attach_deasserted(&switchFire);
    wait(0.3);
    fire.setSampleFrequency();    
}



void accelerometerSet()
{
    acc.setBitDepth(MMA8452::BIT_DEPTH_12);
    acc.setDynamicRange(MMA8452::DYNAMIC_RANGE_2G);
    acc.setDataRate(MMA8452::RATE_200);
}

void uLCDSet()
{
    uLCD.baudrate(300000);
    wait(0.5);
    uLCD.cls();   
}


void spawnAliens()
{
    objects.push_back(new Ship(rand()%(109), 112));
    for(int i = 0; i < 6; i++) {
        int xC = rand() % 109;
        int yC = 18 * i;
        switch(rand() % 4) {
            case 0:
                objects.push_back(new AlienAlice(xC, yC));
                break;
            case 1:
                objects.push_back(new AlienBob(xC, yC));
                break;
            case 2:
                objects.push_back(new AlienAlvin(xC, yC));
                break;
            case 3:
                objects.push_back(new AlienJeff(xC, yC));
                break;
        }
    }

    numLeft = 6;
}

void drawAliens()
{
    uLCD.cls();
    for (int i = 0; i < objects.size(); i++)
    {
        objects[i]->draw(uLCD);   
    }
}

void sound(Speaker &inSpeaker)
{
    inSpeaker.PlayNote(100, 0.3, 0.3);
    inSpeaker.PlayNote(300, 0.3, 0.3);
    inSpeaker.PlayNote(500, 0.3, 0.3);
    inSpeaker.PlayNote(700, 0.3, 0.3);
    inSpeaker.PlayNote(900, 0.3, 0.3);  
}


bool collision(ScreenObject* bullet, ScreenObject* object)
{
    if ((bullet->getTx() > (object->getBx()-1)) || (bullet->getBx() < (object->getTx()+1)) || (bullet->getTy() > (object->getBy()-1)) || (bullet->getBy() < (object->getTy()+1))) 
    {
        return false;
    } 
    else 
    {
        mySpeaker.PlayNote(900, 0.3, 0.3);
        return true;
    }
}

void deleteAlien(int index)
{
    objects[index]->remove(uLCD);
    delete objects[index];
    objects.erase(objects.begin() + index);
}

void reDraw()
{
    static_cast<Ship*>(objects[0])->updateSpeed(acc);
    
    for(int i = 0; i < objects.size(); i++) {
        objects[i]->update(uLCD);
    }

    if(bullet) 
    {
        for(int i = objects.size() - 2; i > 0; i--) 
        {
            if(collision(objects[objects.size() - 1], objects[i])) 
            {
                deleteAlien(i);
                numLeft--;
                static_cast<Bullet*>(objects[objects.size() - 1])->setActive(false);
                break;
            }
        }
    }
}
void gameOver(uLCD_4DGL &inLCD, int inTime)
{
    inLCD.cls();
    mySpeaker.PlayNote(900, 0.3, 0.3);
    mySpeaker.PlayNote(900, 0.3, 0.3);
    mySpeaker.PlayNote(900, 0.3, 0.3);
    inLCD.printf("\n\n\n\n    You saved \n    the Earth!\n\n\n\n\n");
    inLCD.printf("   %d seconds", t.read());
    
    while(1)
    {
        wait(1.0);   
    }   
}

int main()
{
    srand(time(0));
    buttonSet();
    accelerometerSet();
    uLCDSet();
    while(1)
    {
        sound(mySpeaker);
        spawnAliens();
        drawAliens();
        t.start();
        while (1) 
        {
        if(bullet && !(static_cast<Bullet*>(objects[objects.size() - 1])->getActive())) 
        {
            deleteAlien(objects.size() - 1);
            bullet = false;
        }

        if(numLeft == 0)
        {
            t.stop();
            break;
        }

        reDraw();

        if(bullet) 
        {
            if(objects.size() == (numLeft + 1)) 
            {
                objects.push_back(new Bullet(objects[0]->getTx() + ((SHIP_WIDTH - BULLET_WIDTH) / 2), objects[0]->getTy()));
            }
        }
    }
    
    for(int i = 0; i < objects.size(); i++)
    {
        deleteAlien(i);   
    }
    
    gameOver(uLCD, t.read());
    }
        
}