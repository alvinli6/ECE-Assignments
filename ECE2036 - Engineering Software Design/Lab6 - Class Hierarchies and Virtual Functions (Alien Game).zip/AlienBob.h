#ifndef ALIENBOB_H
#define ALIENBOB_H
#include "ScreenObject.h"

#define BOB_SPEED 2
#define W 0xFFFFFF      //white
#define _ 0x000000      //black
#define R   0xFF0000    //red
#define G   0x00FF00    //green
#define Bl  0x0000FF    //blue

class AlienBob: public ScreenObject
{
    
public:

    AlienBob(int, int);
    virtual void draw(uLCD_4DGL &inLCD);
    virtual void update(uLCD_4DGL &inLCD);
    virtual void remove(uLCD_4DGL &inLCD);
    
    int getState();
    void setState(int);
    
private:
    static int bob[ALIEN_HEIGHT*ALIEN_WIDTH];
    static int bobDown[ALIEN_HEIGHT*ALIEN_WIDTH];
    static int removed[ALIEN_HEIGHT*ALIEN_WIDTH];
    int state;
};

#endif