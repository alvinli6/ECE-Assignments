#include "Ship.h" 

Ship::Ship(int x, int y): ScreenObject(x, y, SHIPSPEED)
{
    Bx = x + SHIP_WIDTH;
    By = y + SHIP_HEIGHT;
}

void Ship::draw(uLCD_4DGL &inLCD)
{
    inLCD.filled_rectangle(Tx, Ty, Bx, By, 0xFF0000);
}

void Ship::update(uLCD_4DGL &inLCD)
{
    remove(inLCD);

    Tx = Tx + speed;
    Bx = Bx + speed;

    if(Tx > 109) 
    {
        Tx = 109;
        Bx = 120;
    } 
    else if(Tx < 0) 
    {
        Tx = 0;
        Bx = 11;
    }

    draw(inLCD);
}

void Ship::remove(uLCD_4DGL &inLCD) 
{
    inLCD.filled_rectangle(Tx, Ty, Bx, By, BLACK);
}

void Ship::updateSpeed(MMA8452 &inAcc) 
{
    double reading;
    inAcc.readYGravity(&reading);
    speed = (int)(SHIPMULT * reading);
}
