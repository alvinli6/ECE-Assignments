#include "AlienAlice.h"


int AlienAlice::alice[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,_,_,R,R,R,_,_,_,_,
    _,R,R,R,R,R,R,R,R,R,_,
     R,R,R,R,R,R,R,R,R,R,R,
    R,R,R,_,_,R,_,_,R,R,R,
    G,G,G,G,G,G,G,G,G,G,G,
    _,_,_,G,G,_,G,G,_,_,_,
    _,_,G,G,_,_,_,G,G,_,_,
    G,G,_,_,_,G,_,_,_,G,G,
};

int AlienAlice::removed[ALIEN_WIDTH*ALIEN_HEIGHT] = 
{
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
    _,_,_,_,_,_,_,_,_,_,_,
};

AlienAlice::AlienAlice(int x, int y): ScreenObject(x, y, ALICE_SPEED)
{
}

void AlienAlice::draw(uLCD_4DGL &inLCD)
{
    inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, alice);
}

void AlienAlice::update(uLCD_4DGL &inLCD)
{
    remove(inLCD);
    Tx += speed;
    Bx += speed;
    
    if (Tx > 120 - ALIEN_WIDTH)
    {
        Tx = 120 - ALIEN_WIDTH;
        Bx = 120;
        speed = speed*(-1);
    }
    else if (Tx < 0)
    {
        Tx = 0;
        Bx = ALIEN_WIDTH;
        speed = speed*(-1);
    }
    
    draw(inLCD);
}

void AlienAlice::remove(uLCD_4DGL &inLCD)
{
    inLCD.BLIT(Tx, Ty, ALIEN_WIDTH, ALIEN_HEIGHT, removed);   
}
