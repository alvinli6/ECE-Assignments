#include "Bullet.h" 

Bullet::Bullet(int x, int y): ScreenObject(x, y, BULLET_SPEED) 
{
    Bx = x + BULLET_WIDTH;
    By = y + BULLET_HEIGHT;
    active = true;
}

bool Bullet::getActive() 
{
    return active;
}

void Bullet::setActive(bool inActive) 
{
    active = inActive;
}
void Bullet::draw(uLCD_4DGL &inLCD)
{
    inLCD.filled_rectangle(Tx, Ty, Bx, By, W);
}

void Bullet::update(uLCD_4DGL &inLCD) 
{
    remove(inLCD);
    Ty = Ty + speed;
    By = By + speed;
    if(Ty >= 0) 
    {
        draw(inLCD);
    } 
    else 
    {
        active = false;
    }
}

void Bullet::remove(uLCD_4DGL &inLCD) 
{
    inLCD.filled_rectangle(Tx, Ty, Bx, By, 0x000000);
}
