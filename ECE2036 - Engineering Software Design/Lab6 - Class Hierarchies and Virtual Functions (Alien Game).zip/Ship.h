#ifndef SHIP_H // Include guard
#define SHIP_H

#include "ScreenObject.h"
#include "MMA8452.h"

#define SHIP_HEIGHT 8
#define SHIP_WIDTH 11
#define SHIPMULT 10
#define SHIPSPEED 1


class Ship: public ScreenObject
{
public:
    Ship(int, int); 
    virtual void draw(uLCD_4DGL &inLCD); 
    virtual void update(uLCD_4DGL &inLCD);
    virtual void remove(uLCD_4DGL &inLCD);
    void updateSpeed(MMA8452 &inAcc);
};

#endif